<?php

  
error_reporting(1);
$conn = new mysqli("localhost","root","","jobportal");

?>

