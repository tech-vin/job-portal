
<footer id="contactus" style="background-color: #1f1f1f;"  >
	
   
    <div class="container row" style="width:100%">
	<div class="col-md-4 col-md-offset-2">
	
	<p style="color: aqua" class="footer-links">
			<a style="color: aqua" href="#intro">Home</a>  
		</p>
            <h3 style="color: aqua"><a href="#"> Developed by <h3 style="font-family:audiowide;display:inline">Kulwinder Toor</h3> </a></h3>
		
          
		
		
    </div>
    
    
    <div class="col-md-3 col-md-offset-3">
			<div id="contact" class="container-fluid bg-grey">
                            <h2 class="text-center " style="font-family:Comfortaa;color:aqua">CONTACT US</h2>
  
   <br>
    <div >
      <p>Contact us </p>
      <p><span class="glyphicon glyphicon-map-marker"></span> Kulwinder Toor </p>
      <p><span class="glyphicon glyphicon-phone"></span> +918437496125</p>
      <p><span class="glyphicon glyphicon-envelope"></span> uic.18mca8127@gmail.com</p>
    </div>
    
  
</div>
</div>
    
    </div>
	
	

	
</footer>	